<?php $__env->startSection('konten'); ?>
<div class="pb-3"><a href="/cv/1" class="btn btn-secondary">Kembali</a></div>

<form  action="<?php echo e(route('profile.update', ['id' => $profile->id])); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label for="nama" class="form-label">Nama</label>
        <input type="text" class="form-control" name="nama" id="nama" aria-describedby="helpId" placeholder="Nama" value="<?php echo e($profile->nama); ?>">
    </div>

    <div class="mb-3">
        <label for="alamat" class="form-label">Alamat</label>
        <input type="text" class="form-control form-control sm" name="alamat" id="alamat" aria-describedby="helpId" placeholder="Alamat" value="<?php echo e($profile->alamat); ?>">
    </div>

    <div class="mb-3">
        <label for="kontak" class="form-label">Kontak</label>
        <input type="text" class="form-control form-control sm" name="kontak" id="kontak" aria-describedby="helpId" placeholder="Kontak" value="<?php echo e($profile->kontak); ?>">
    </div>

    <!-- Riwayat Pendidikan -->
    <div class="mb-3">
        <label for="riwayatPendidikan" class="form-label">Riwayat Pendidikan</label>
        <table class="table">
            <thead>
                <tr>
                    <th>Nama Sekolah/Universitas</th>
                    <th>Tahun Masuk</th>
                    <th>Tahun Keluar</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="Pendidikan">
                <?php $__currentLoopData = $riwayatPendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pendidikan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <input type="hidden" name="riwayatPendidikan[<?php echo e($index); ?>][id]" value="<?php echo e($pendidikan->id); ?>">
                        <td><input type="text" class="form-control" name="riwayatPendidikan[<?php echo e($index); ?>][namaSekolah]" placeholder="Nama Sekolah/Universitas" value="<?php echo e($pendidikan->namaSekolah); ?>" required></td>
                        <td><input type="text" class="form-control" name="riwayatPendidikan[<?php echo e($index); ?>][thn_mulai]" placeholder="Tahun Masuk" value="<?php echo e($pendidikan->thn_mulai); ?>" required></td>
                        <td><input type="text" class="form-control" name="riwayatPendidikan[<?php echo e($index); ?>][thn_akhir]" placeholder="Tahun Keluar" value="<?php echo e($pendidikan->thn_akhir); ?>" required></td>
                        <td>
                            <button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">Hapus</button>
                            <input type="hidden" name="riwayatPendidikan[<?php echo e($index); ?>][deleted]" value="false">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="button" class="btn btn-secondary" id="tambahRiwayatPendidikan">Tambah Riwayat Pendidikan</button>
    </div>


    <!-- Riwayat Pekerjaan -->
    <div class="mb-3">
        <label for="riwayatPekerjaan" class="form-label">Riwayat Pekerjaan</label>
        <table class="table">
            <thead>
                <tr>
                    <th>Nama Perusahaan</th>
                    <th>Domisili Perusahaan</th>
                    <th>Jabatan</th>
                    <th>Tanggal Mulai</th>
                    <th>Tanggal Akhir</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="Pekerjaan">
                <?php $__currentLoopData = $riwayatPekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pekerjaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <input type="hidden" name="riwayatPekerjaan[<?php echo e($index); ?>][id]" value="<?php echo e($pekerjaan->id); ?>">
                        <td><input type="text" class="form-control" name="riwayatPekerjaan[<?php echo e($index); ?>][namaPerusahaan]" placeholder="Nama Perusahaan" value="<?php echo e($pekerjaan->namaPerusahaan); ?>" required></td>
                        <td><input type="text" class="form-control" name="riwayatPekerjaan[<?php echo e($index); ?>][domisilPerusahaan]" placeholder="Domisili Perusahaan" value="<?php echo e($pekerjaan->domisilPerusahaan); ?>" required></td>
                        <td><input type="text" class="form-control" name="riwayatPekerjaan[<?php echo e($index); ?>][jabatan]" placeholder="Jabatan" value="<?php echo e($pekerjaan->jabatan); ?>" required></td>
                        <td><input type="date" class="form-control" name="riwayatPekerjaan[<?php echo e($index); ?>][tgl_mulai]" value="<?php echo e($pekerjaan->tgl_mulai); ?>" required></td>
                        <td><input type="date" class="form-control" name="riwayatPekerjaan[<?php echo e($index); ?>][tgl_akhir]" value="<?php echo e($pekerjaan->tgl_akhir); ?>" required></td>
                        <td>
                            <button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">Hapus</button>
                            <input type="hidden" name="riwayatPekerjaan[<?php echo e($index); ?>][deleted]" value="false">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="button" class="btn btn-secondary" id="tambahRiwayatPekerjaan">Tambah Riwayat Pekerjaan</button>
    </div>

    <div class="mb-3">
        <label for="hardskill" class="form-label">Skills</label>
        <table class="table">
            <thead>
                <tr>
                    <th>Nama Skill</th>
                    <th>Tingkat (%)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="hardSkill">
            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <input type="hidden" name="skills[<?php echo e($index); ?>][id]" value="<?php echo e($skill->id); ?>">
                    <td><input type="text" class="form-control" name="skills[<?php echo e($index); ?>][namaSkill]" value="<?php echo e($skill->namaSkill); ?>" placeholder="Nama Skill" required></td>
                    <td><input type="number" class="form-control" name="skills[<?php echo e($index); ?>][tingkatanSkill]" value="<?php echo e($skill->tingkatanSkill); ?>" placeholder="Tingkat (%) (0-100)" required></td>
                    <td>
                        <button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">Hapus</button>
                        <input type="hidden" name="skills[<?php echo e($index); ?>][deleted]" value="false">
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="button" class="btn btn-secondary" id="tambahSkill">Tambah skill</button>
    </div>

    <div class="mb-3">
        <label for="dataDiri" class="form-label">Deskripsi Diri</label>
        <textarea class="form-control" rows="5" name="dataDiri"><?php echo e($profile->dataDiri); ?></textarea>
    </div>

        <button class="btn btn-primary" name="simpan" type="submit">UPDATE</button>
    </div>
</form>

<script>
    let riwayatPekerjaanIndex = <?php echo e(count($riwayatPekerjaan)); ?>;

    document.getElementById('tambahRiwayatPekerjaan').addEventListener('click', function() {
        let newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td><input type="text" class="form-control" name="riwayatPekerjaan[${riwayatPekerjaanIndex}][namaPerusahaan]" placeholder="Nama Perusahaan" required></td>
            <td><input type="text" class="form-control" name="riwayatPekerjaan[${riwayatPekerjaanIndex}][domisilPerusahaan]" placeholder="Domisili Perusahaan" required></td>
            <td><input type="text" class="form-control" name="riwayatPekerjaan[${riwayatPekerjaanIndex}][jabatan]" placeholder="Jabatan" required></td>
            <td><input type="date" class="form-control" name="riwayatPekerjaan[${riwayatPekerjaanIndex}][tgl_mulai]" required></td>
            <td><input type="date" class="form-control" name="riwayatPekerjaan[${riwayatPekerjaanIndex}][tgl_akhir]" required></td>
            <td>
                <button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">Hapus</button>
                <input type="hidden" name="riwayatPekerjaan[<?php echo e($index); ?>][deleted]" value="false">
            </td>
        `;
        document.getElementById('Pekerjaan').appendChild(newRow);
        riwayatPekerjaanIndex++;
    });

    function hapusBaris(button) {
        var row = button.closest('tr');
        row.querySelector('[name$="[deleted]"]').value = true;
        row.style.display = 'none'; // Sembunyikan baris
    }

    let riwayatPendidikanIndex = <?php echo e(count($riwayatPendidikan)); ?>;
    document.getElementById('tambahRiwayatPendidikan').addEventListener('click', function() {
        let newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td><input type="text" class="form-control" name="riwayatPendidikan[${riwayatPendidikanIndex}][namaSekolah]" placeholder="Nama Sekolah/Universitas" required></td>
            <td><input type="text" class="form-control" name="riwayatPendidikan[${riwayatPendidikanIndex}][thn_mulai]" placeholder="Tahun Masuk" required></td>
            <td><input type="text" class="form-control" name="riwayatPendidikan[${riwayatPendidikanIndex}][thn_akhir]" placeholder="Tahun Keluar" required></td>
            <td>
                <button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">Hapus</button>
                <input type="hidden" name="riwayatPendidikan[<?php echo e($index); ?>][deleted]" value="false">
            </td>
        `;
        document.getElementById('Pendidikan').appendChild(newRow);
        riwayatPekerjaanIndex++;
    });

    let hardSkillIndex = <?php echo e(count($skills)); ?>;
    // console.log("Nilai dari hardSkillIndex adalah: " + hardSkillIndex);
    document.getElementById('tambahSkill').addEventListener('click', function() {
        let newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td><input type="text" class="form-control" name="skills[${hardSkillIndex}][namaSkill]" placeholder="Nama Skill" required></td>
            <td><input type="number" class="form-control" name="skills[${hardSkillIndex}][tingkatanSkill]" placeholder="Tingkat (%) (0-100)" required></td>
            <td>
                <button type="button" class="btn btn-danger btn-sm" onclick="hapusBaris(this)">Hapus</button>
                <input type="hidden" name="skills[<?php echo e($index); ?>][deleted]" value="false">
            </td>
        `;
        document.getElementById('hardSkill').appendChild(newRow);
        hardSkillIndex++;
    });

    function hapusBaris(button) {
        var row = button.closest('tr');
        row.querySelector('[name$="[deleted]"]').value = true;
        row.style.display = 'none'; // Sembunyikan baris
    }





</script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Proyek3_WP7\resources\views/dashboard/profile/edit.blade.php ENDPATH**/ ?>