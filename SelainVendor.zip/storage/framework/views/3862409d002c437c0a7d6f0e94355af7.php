<?php $__env->startSection('konten2'); ?>  
<div class="content">
    <h2><strong>List CV</strong></h2>
    
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card" style="width: 75%">
                    <div class="d-flex align-items-center justify-content-center">
                        <img src="<?php echo e(asset('storage/' . $item['profile']->gambar)); ?>" alt="" class="card-img-top" style="object-fit: cover; height: 200px;">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title" style="margin-bottom: 10px; font-size: 18px; color: white;"><?php echo e($item['profile']->nama); ?></h5>

                        <h5 class="judul-card">Pengalaman Bekerja</h5>
                        <?php $__currentLoopData = $item['riwayatPekerjaan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayatpk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($riwayatpk->profile_id == $item['profile']->id): ?>
                                <?php
                                    // Konversi tanggal ke dalam objek Carbon untuk memanfaatkan fitur perbedaan tahun
                                    $tglMulai = \Carbon\Carbon::parse($riwayatpk->tgl_mulai);
                                    $tglAkhir = \Carbon\Carbon::parse($riwayatpk->tgl_akhir);
                            
                                    // Hitung selisih tahun
                                    $selisihTahun = $tglMulai->diffInYears($tglAkhir);
                                ?>
                                <p class="card-text"><?php echo e($riwayatpk->namaPerusahaan); ?> - <?php echo e($riwayatpk->jabatan); ?></p>
                                <p class="card-text"><?php echo e($selisihTahun); ?> tahun</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <h5 class="judul-card">Keahlian</h5>
                        <?php $__currentLoopData = $item['keahlian']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($skill->profile_id == $item['profile']->id): ?>
                                <p class="card-text"><?php echo e($skill->namaSkill); ?>-<?php echo e($skill->tingkatanSkill); ?>%</p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('cv.show', ['cv' => $item['profile']->id])); ?>" class="btn btn-primary btn-lg" style="font-size: 16px; padding: 10px 20px; margin-top: 10px;">Lihat</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Proyek3_WP7\resources\views/listcv.blade.php ENDPATH**/ ?>