;

<?php $__env->startSection('konten'); ?>
<div class="table-responsive">
    <?php if($user->email_verified_at === null): ?>
        <div class="alert alert-danger" role="alert">
            Email belum diverifikasi, klik <a href="https://mail.google.com/" class="alert-link">di sini</a> untuk menuju laman email Anda.
            <?php if(session('resent')): ?>
                <div class="alert alert-success mt-2" role="alert">
                    Verifikasi email telah dikirim ulang. Silakan cek email Anda.
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('verification.resend')); ?>" method="post" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-link p-0 m-0 align-baseline">Kirim Ulang Verifikasi</button>.
            </form>
        </div>
    <?php endif; ?>

    <div class="pb-3"><a href="<?php echo e(route('profile.create')); ?>"class="btn btn-primary">+ Tambah profile</a></div>
    <table class="table table-stripped">
        <tbody>
            <?php $i=1;?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->user_id === $currentId): ?>
                    <tr>
                        <td><img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" alt="" width="100"></td>
                        <td class="col-9"><?php echo e($item->nama); ?></td>
                        <td>
                            <a href="<?php echo e(route('depan.show', ['depan' => $item->id])); ?>" class="btn btn-primary">Show</a>
                            <form onsubmit="return confirm('Yakin ingin menghapus data ini?')"
                                action="<?php echo e(route('profile.destroy', $item->id)); ?>" class="d-inline" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" type="submit" name='submit'>Del</button>
                            </form>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Proyek3_WP7\resources\views/depan/dataprofil.blade.php ENDPATH**/ ?>